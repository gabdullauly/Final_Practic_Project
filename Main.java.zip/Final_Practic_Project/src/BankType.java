public enum BankType {
    Kaspi,
    Halyk,
    Jusan,
    Alpha
}
